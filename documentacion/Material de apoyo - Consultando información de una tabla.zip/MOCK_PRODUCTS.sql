create table MOCK_PRODUCTS (
	id INT,
	product_name VARCHAR(50),
	price INT,
	stock VARCHAR(50)
);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (1, 'Liners - Baking Cups', 298, true);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (2, 'Veal - Sweetbread', 6552, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (3, 'Oneshot Automatic Soap System', 6667, true);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (4, 'Cookies - Fortune', 882, true);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (5, 'Oil - Truffle, White', 5900, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (6, 'Appetizer - Smoked Salmon / Dill', 1263, true);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (7, 'Petite Baguette', 5366, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (8, 'Chocolate - Liqueur Cups With Foil', 2797, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (9, 'Juice - Apple, 341 Ml', 3654, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (10, 'Grouper - Fresh', 1266, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (11, 'Milk - Condensed', 5998, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (12, 'Straw - Regular', 9688, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (13, 'Beer - Alexander Kieths, Pale Ale', 4173, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (14, 'Rice - Basmati', 1036, true);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (15, 'Blueberries - Frozen', 2462, true);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (16, 'Ecolab - Lime - A - Way 4/4 L', 8092, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (17, 'Vermouth - Sweet, Cinzano', 6639, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (18, 'Kohlrabi', 7868, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (19, 'Mushroom - Morel Frozen', 7208, false);
insert into MOCK_PRODUCTS (id, product_name, price, stock) values (20, 'Syrup - Monin, Amaretta', 5486, false);
